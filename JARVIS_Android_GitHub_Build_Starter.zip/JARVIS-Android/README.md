# JARVIS Android starter

This is a small Android starter app for the JARVIS project.

## Build on GitHub (no computer required)
1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build JARVIS APK** and tap **Run workflow** (or push to `main`).
4. When the run finishes, open it and download the `JARVIS-debug-apk` artifact.

## Current limits
This starter provides a blue JARVIS screen, tap-to-speak Android speech recognition, and spoken text-to-speech replies. It is **not** the complete hands-free assistant yet. It does not include always-on wake-word detection, cloud AI, notification reading, or phone-control integrations. Those need additional implementation, permissions, and device testing. It is not safe to claim the wake word works until it is implemented and tested.
